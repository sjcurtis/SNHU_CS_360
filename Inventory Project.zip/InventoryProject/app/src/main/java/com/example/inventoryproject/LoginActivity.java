package com.example.inventoryproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Console;

public class LoginActivity extends AppCompatActivity {

    private EditText username, password;

    private Button register;
    private Button login;
    private DBHandlerLogin dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializing variables
        register = findViewById(R.id.buttonRegister);
        login = findViewById(R.id.buttonLogin);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);

        dbHandler = new DBHandlerLogin(LoginActivity.this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = username.getText().toString();
                String pass = password.getText().toString();

                // validating if the text fields are empty or not.
                if (user.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Add new user to database
                dbHandler.addNewUser(user, pass);

                Toast.makeText(LoginActivity.this, "User has been added.", Toast.LENGTH_SHORT).show();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = username.getText().toString();
                String pass = password.getText().toString();
                int userFound = 0;

                // Validating if the text fields are empty or not.
                if (user.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                userFound = dbHandler.lookupUser(user, pass);

                if (userFound > 0)
                    try {
                        Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                        startActivity(intent);
                    }
                    catch (Exception ex){
                        Log.e("intent", ex.toString());
                    }

                else
                    Toast.makeText(LoginActivity.this, "User not found.", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
